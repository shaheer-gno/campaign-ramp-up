# Panda Planner — Amazon Ads Sample Data (Campaign Ramp-Up)

Seller: Panda Planner LLC · Marketplace: Amazon.com (US) · Exported: 2026-10-23

All files are CSV with a header row. Money is USD.

## Important: data window

Daily performance files cover **2026-09-23 to 2026-10-13**. When implementing
"spent less than $3 yesterday", treat the latest `report_date` in the data
(2026-10-13) as "yesterday". Production data is continuous; this sample just
ends there.

## State files (current configuration — what "apply" would change)

| File | Grain | Contents |
|---|---|---|
| `campaigns-state.csv` | 1 row per campaign | Name, state, ad product (SP/SB/SD), bid strategy, budget, and the four placement bid adjustments: `placement_top_pct` (Top of Search), `placement_rest_of_search_pct` (Rest of Search), `placement_product_page_pct` (Product Pages), `placement_amazon_business_pct` (B2B). `audience_bids` is a JSON string of audience bid adjustments. |
| `ad-groups-state.csv` | 1 row per ad group | Name, state, `default_bid` (used when a target has no explicit bid). |
| `targets-state.csv` | 1 row per target/keyword | Current `bid`, keyword text or targeting clause, match type, state, `negative` flag (negatives are never ramped). |
| `audiences-dictionary.csv` | 1 row per audience | Maps audience IDs used in `campaigns-state.audience_bids` to names/paths. |

## Performance files (daily grain, drives selection)

| File | Grain | Contents |
|---|---|---|
| `campaign-daily-30d.csv` | campaign × day | Spend (`cost`), clicks, impressions, 7-day purchases/sales. Drives the "spent < $3 yesterday" campaign filter. |
| `target-daily-30d.csv` | target/keyword × day | Clicks, cost, bid at report time. Drives the "fewer than ~5 clicks over yesterday + day before" rule. |
| `placement-daily-30d.csv` | campaign × placement × day | Per-placement traffic. `placement_classification` values: `Top of Search on-Amazon` (TOS), `Other on-Amazon` (Rest of Search), `Detail Page on-Amazon` (Product Pages), `Amazon Business` (B2B), `Off Amazon`. |

## Notes

- The Campaign Ramp-Up scope is Sponsored Products; filter on
  `ad_product = 'SPONSORED_PRODUCTS'`. SB/SD rows are included for context only.
- `cost` and `spend` are the same for Sponsored Products; prefer `cost`.
- Join keys: `campaign_id`, `ad_group_id`, `target_id`/`keyword_id`.
- Placement/audience adjustments are percentages on top of the base bid
  (e.g. `placement_top_pct = 50` means +50% at Top of Search).
